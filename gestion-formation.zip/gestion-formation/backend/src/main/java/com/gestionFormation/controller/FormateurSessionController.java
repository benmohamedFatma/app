package com.gestionFormation.controller;

import com.gestionFormation.model.FormateurSessionEntity;
import com.gestionFormation.service.FormateurSessionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/formateur-sessions")
@CrossOrigin("http://localhost:3000/")
public class FormateurSessionController {

    private final FormateurSessionService formateurSessionService;

    @Autowired
    public FormateurSessionController(FormateurSessionService formateurSessionService) {
        this.formateurSessionService = formateurSessionService;
    }

    @GetMapping
    public List<FormateurSessionEntity> getAllFormateurSessions() {
        return formateurSessionService.getAllFormateurSessions();
    }

    @GetMapping("/{id}")
    public FormateurSessionEntity getFormateurSessionById(@PathVariable Integer id) {
        return formateurSessionService.getFormateurSessionById(id).orElse(null);
    }

    @PostMapping
    public FormateurSessionEntity createFormateurSession(@RequestBody FormateurSessionEntity formateurSession) {
        return formateurSessionService.createFormateurSession(formateurSession);
    }

    @DeleteMapping("/{id}")
    public void deleteFormateurSessionById(@PathVariable Integer id) {
        formateurSessionService.deleteFormateurSessionById(id);
    }
}
