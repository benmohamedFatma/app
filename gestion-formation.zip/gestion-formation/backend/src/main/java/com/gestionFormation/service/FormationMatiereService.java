package com.gestionFormation.service;

import com.gestionFormation.model.FormationEntity;
import com.gestionFormation.model.MatièreEntity;
import com.gestionFormation.model.FormationMatiereEntity;
import com.gestionFormation.repository.FormationMatiereRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FormationMatiereService {

    private final FormationMatiereRepository formationMatiereRepository;

    @Autowired
    public FormationMatiereService(FormationMatiereRepository formationMatiereRepository) {
        this.formationMatiereRepository = formationMatiereRepository;
    }

    public List<FormationMatiereEntity> getAllFormationMatieres() {
        return formationMatiereRepository.findAll();
    }

    public Optional<FormationMatiereEntity> getFormationMatiereById(Integer id) {
        return formationMatiereRepository.findById(id);
    }

    public FormationMatiereEntity createFormationMatiere(FormationMatiereEntity formationMatiere) {
        return formationMatiereRepository.save(formationMatiere);
    }

    public void deleteFormationMatiereById(Integer id) {
        formationMatiereRepository.deleteById(id);
    }
}
