//package com.gestionFormation.service;
//import com.gestionFormation.model.InsecriptionEntity;
//import org.springframework.stereotype.Service;
//import com.gestionFormation.repository.InscriptionRepository;
//
//import java.util.List;
//import java.util.Optional;
//
//@Service
//public class InscriptionService {
//    private final InscriptionRepository inscriptionRepository;
//
//    public InscriptionService(InscriptionRepository inscriptionRepository) {
//        this.inscriptionRepository = inscriptionRepository;
//    }
//
//    public List<InsecriptionEntity> getAllInscriptions() {
//        return inscriptionRepository.findAll();
//    }
//
//    public Optional<InsecriptionEntity> getInscriptionById(Integer id) {
//        return inscriptionRepository.findById(id);
//    }
//
//    public InsecriptionEntity createInscription(InsecriptionEntity inscription) {
//        return inscriptionRepository.save(inscription);
//    }
//
//    public InsecriptionEntity updateInscription(Integer id, InsecriptionEntity updatedInscription) {
//        Optional<InsecriptionEntity> existingInscription = inscriptionRepository.findById(id);
//
//        if (existingInscription.isPresent()) {
//            InsecriptionEntity inscriptionToUpdate = existingInscription.get();
//            inscriptionToUpdate.setMontant(updatedInscription.getMontant());
//            inscriptionToUpdate.setDateInscription(updatedInscription.getDateInscription());
//            return inscriptionRepository.save(inscriptionToUpdate);
//        } else {
//            return null;
//        }
//    }
//    public void deleteInscription(Integer id) {
//        inscriptionRepository.deleteById(id);
//    }
//}
