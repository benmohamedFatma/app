package com.gestionFormation.controller;

import com.gestionFormation.model.EtudiantEntity;
import com.gestionFormation.service.EtudiantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/etudiants")
@CrossOrigin("http://localhost:3000/")
public class EtudiantController {

    private final EtudiantService etudiantService;

    @Autowired
    public EtudiantController(EtudiantService etudiantService) {
        this.etudiantService = etudiantService;
    }

    @GetMapping
    public List<EtudiantEntity> getAllEtudiants() {
        return etudiantService.getAllEtudiants();
    }

    @GetMapping("/{id}")
    public ResponseEntity<EtudiantEntity> getEtudiantById(@PathVariable Integer id) {
        Optional<EtudiantEntity> etudiant = etudiantService.getEtudiantById(id);
        return etudiant.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PostMapping
    public ResponseEntity<EtudiantEntity> createEtudiant(@RequestBody EtudiantEntity etudiant) {
        EtudiantEntity createdEtudiant = etudiantService.createEtudiant(etudiant);
        return new ResponseEntity<>(createdEtudiant, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<EtudiantEntity> updateEtudiant(@PathVariable Integer id, @RequestBody EtudiantEntity updatedEtudiant) {
        EtudiantEntity updated = etudiantService.updateEtudiant(id, updatedEtudiant);

        if (updated != null) {
            return new ResponseEntity<>(updated, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteEtudiant(@PathVariable Integer id) {
        System.out.println("Deleting etudiant with ID: " + id);
        etudiantService.deleteEtudiant(id);
        return ResponseEntity.ok("Etudiant deleted successfully");
    }

}
