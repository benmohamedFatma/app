package com.gestionFormation.repository;

import com.gestionFormation.model.FormateurEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FormateurRepository extends JpaRepository<FormateurEntity, Integer> {
}
