package com.gestionFormation.service;
import com.gestionFormation.model.EtudiantEntity;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import com.gestionFormation.repository.EtudiantRepository;

import java.util.List;
import java.util.Optional;
@AllArgsConstructor
@Service
    public class EtudiantService {
        private final EtudiantRepository etudiantRepository;
        public List<EtudiantEntity> getAllEtudiants() {
            return etudiantRepository.findAll();
        }

        public Optional<EtudiantEntity> getEtudiantById(Integer id) {
            return etudiantRepository.findById(id);
        }

        public EtudiantEntity createEtudiant(EtudiantEntity etudiant) {
            return etudiantRepository.save(etudiant);
        }

        public EtudiantEntity updateEtudiant(Integer id, EtudiantEntity updatedEtudiant) {
            Optional<EtudiantEntity> existingEtudiant = etudiantRepository.findById(id);

            if (existingEtudiant.isPresent()) {
                EtudiantEntity etudiantToUpdate = existingEtudiant.get();
                etudiantToUpdate.setNom(updatedEtudiant.getNom());
                etudiantToUpdate.setPrenom(updatedEtudiant.getPrenom());
                etudiantToUpdate.setNumTEL(updatedEtudiant.getNumTEL());
                return etudiantRepository.save(etudiantToUpdate);
            } else {
                return null;
            }
        }

        public void deleteEtudiant(Integer id) {
            etudiantRepository.deleteById(id);
        }
    }

