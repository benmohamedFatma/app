package com.gestionFormation.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.HashSet;
import java.util.Set;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Table(name = "Presence")
@Entity
public class PrésenceEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "est_present")
    private boolean estPresent;

//    @JsonIgnore
//    @ManyToMany
//    @JoinTable(
//            name = "seance_presence",
//            joinColumns = @JoinColumn(name = "presence_id"),
//            inverseJoinColumns = @JoinColumn(name = "seance_id"))
//    private Set<SeanceEntity> seances = new HashSet<>();

}
