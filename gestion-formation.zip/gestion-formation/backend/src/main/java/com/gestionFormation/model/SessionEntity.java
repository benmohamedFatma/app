package com.gestionFormation.model;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "Session")
public class SessionEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idSession;

    @Column(name = "dateDebut")
    private LocalDate dateDebut;

    @Column(name = "dateFin")
    private LocalDate dateFin;

    @ManyToOne
    @JoinColumn(name = "formation")
    private FormationEntity formation;

    @ManyToOne
    @JoinColumn(name = "formateur") // Ajoutez cette ligne pour la référence au formateur
    private FormateurEntity formateur; // Assurez-vous d'avoir un modèle pour les formateurs
}
