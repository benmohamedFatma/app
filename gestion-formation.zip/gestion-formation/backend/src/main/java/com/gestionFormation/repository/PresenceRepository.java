package com.gestionFormation.repository;

import com.gestionFormation.model.PrésenceEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PresenceRepository extends JpaRepository<PrésenceEntity,Integer> {
}
