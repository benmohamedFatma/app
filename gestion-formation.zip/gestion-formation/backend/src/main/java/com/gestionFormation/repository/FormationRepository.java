package com.gestionFormation.repository;

import com.gestionFormation.model.FormationEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FormationRepository extends JpaRepository<FormationEntity,Integer> {

}
