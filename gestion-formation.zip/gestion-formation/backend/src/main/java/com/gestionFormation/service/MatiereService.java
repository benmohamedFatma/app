package com.gestionFormation.service;

import com.gestionFormation.model.MatièreEntity;
import org.springframework.stereotype.Service;
import com.gestionFormation.repository.MatiereRepository;

import java.util.List;
import java.util.Optional;

@Service
public class MatiereService {
    private final MatiereRepository matiereRepository;

    public MatiereService(MatiereRepository matiereRepository) {
        this.matiereRepository = matiereRepository;
    }

    public List<MatièreEntity> getAllMatieres() {
        return matiereRepository.findAll();
    }

    public Optional<MatièreEntity> getMatiereById(Integer id) {
        return matiereRepository.findById(id);
    }

    public void createMatiere(MatièreEntity matiere){ matiereRepository.save(matiere);
    }

    public MatièreEntity updateMatiere(Integer id, MatièreEntity updatedMatiere) {
        Optional<MatièreEntity> existingMatiere = matiereRepository.findById(id);

        if (existingMatiere.isPresent()) {
            MatièreEntity matiereToUpdate = existingMatiere.get();
            matiereToUpdate.setNomMatiere(updatedMatiere.getNomMatiere());
            return matiereRepository.save(matiereToUpdate);
        } else {
            return null;
        }
    }

    public void deleteMatiere(Integer id) {
        matiereRepository.deleteById(id);
    }
}
