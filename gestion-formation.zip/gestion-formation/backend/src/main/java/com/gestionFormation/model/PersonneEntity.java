package com.gestionFormation.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@MappedSuperclass
public abstract class PersonneEntity {
    private String email;
    private Long numTEL;
    private String nom;
    private String prenom;
}
