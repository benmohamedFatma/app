package com.gestionFormation.controller;

import com.gestionFormation.model.AdministrateurEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.gestionFormation.service.AdministrateurService;

import java.util.List;

@RestController
@RequestMapping("/admin")
public class AdministrateurController {

    private final AdministrateurService administrateurService;
    @Autowired
    public AdministrateurController(AdministrateurService administrateurService){
        this.administrateurService=administrateurService;
    }

    @GetMapping("/all")
    public List<AdministrateurEntity> getAllAdmins() {
        return administrateurService.getAllAdmins();
    }

    @GetMapping("/{id}")
    public AdministrateurEntity getAdminDetails(@PathVariable Integer id) {
        return administrateurService.getAdminById(id);
    }

    @PostMapping("/create")
    public AdministrateurEntity createAdmin(@RequestBody AdministrateurEntity admin) {
        return administrateurService.createAdmin(admin);
    }

    @PutMapping("/update/{id}")
    public AdministrateurEntity updateAdmin(@PathVariable Integer id, @RequestBody AdministrateurEntity updatedAdmin) {
        return administrateurService.updateAdmin(id, updatedAdmin);
    }

    @DeleteMapping("/delete/{id}")
    public void deleteAdmin(@PathVariable Integer id) {
        administrateurService.deleteAdmin(id);
    }
}
