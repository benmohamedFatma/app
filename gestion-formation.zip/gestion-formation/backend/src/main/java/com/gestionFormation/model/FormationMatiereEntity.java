package com.gestionFormation.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "FormationMatiere")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class FormationMatiereEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "formation_id")
    private FormationEntity formation;

    @ManyToOne
    @JoinColumn(name = "matiere_id")
    private MatièreEntity matiere;
}

