package com.gestionFormation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.gestionFormation.model.AdministrateurEntity;

public interface AdministrateurRepository extends JpaRepository<AdministrateurEntity,Integer> {
}
