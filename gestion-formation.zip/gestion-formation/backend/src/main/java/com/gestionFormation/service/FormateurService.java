package com.gestionFormation.service;

import com.gestionFormation.model.FormateurEntity;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import com.gestionFormation.repository.FormateurRepository;

import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
public class FormateurService {
    private final FormateurRepository formateurRepository;

    public List<FormateurEntity> getAllFormateurs() {
        return formateurRepository.findAll();
    }

    public Optional<FormateurEntity> getFormateurById(Integer id) {
        return formateurRepository.findById(id);
    }

    public FormateurEntity createFormateur(FormateurEntity formateur) {
        return formateurRepository.save(formateur);
    }

    public FormateurEntity updateFormateur(Integer id, FormateurEntity updatedFormateur) {
        Optional<FormateurEntity> existingFormateur = formateurRepository.findById(id);

        if (existingFormateur.isPresent()) {
            FormateurEntity formateurToUpdate = existingFormateur.get();
            formateurToUpdate.setNom(updatedFormateur.getNom());
            formateurToUpdate.setPrenom(updatedFormateur.getPrenom());
            formateurToUpdate.setNumTEL(updatedFormateur.getNumTEL());
            formateurToUpdate.setSpecialite(updatedFormateur.getSpecialite());
            return formateurRepository.save(formateurToUpdate);
        } else {
            return null;
        }
    }
    public void deleteFormateur(Integer id) {
        formateurRepository.deleteById(id);
    }
}
