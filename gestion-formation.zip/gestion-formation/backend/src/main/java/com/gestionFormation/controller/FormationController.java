package com.gestionFormation.controller;

import com.gestionFormation.model.FormationEntity;
import com.gestionFormation.service.FormationService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin("http://localhost:3000/")
@RequestMapping("/formations")
public class FormationController {
    private final FormationService formationService;

    public FormationController(FormationService formationService) {
        this.formationService = formationService;
    }

    @GetMapping
    public List<FormationEntity> getAllFormations() {
        return formationService.getAllFormations();
    }

    @GetMapping("/{id}")
    public ResponseEntity<FormationEntity> getFormationById(@PathVariable Integer id) {
        Optional<FormationEntity> formation = formationService.getFormationById(id);
        return formation.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PostMapping
    public ResponseEntity<FormationEntity> createFormation(@RequestBody FormationEntity formation) {
        FormationEntity createdFormation = formationService.createFormation(formation);
        return new ResponseEntity<>(createdFormation, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updateFormation(@PathVariable Integer id, @RequestBody FormationEntity updatedFormation) {
        FormationEntity updated = formationService.updateFormation(id, updatedFormation);

        if (updated != null) {
            return ResponseEntity.ok("Formation updated");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No such formation");
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteFormation(@PathVariable Integer id) {
        formationService.deleteFormation(id);
        return ResponseEntity.ok("Formation deleted");
    }
}
