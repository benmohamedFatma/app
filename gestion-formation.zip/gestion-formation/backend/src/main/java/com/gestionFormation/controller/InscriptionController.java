//package com.gestionFormation.controller;
//
//import com.gestionFormation.model.InsecriptionEntity;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.*;
//        import com.gestionFormation.service.InscriptionService;
//
//import java.util.List;
//import java.util.Optional;
//
//@RestController
//@RequestMapping("/inscriptions")
//@Controller
//public class InscriptionController {
//
//    private final InscriptionService inscriptionService;
//
//
//    public InscriptionController(InscriptionService inscriptionService) {
//        this.inscriptionService = inscriptionService;
//    }
//
//    @GetMapping
//    public List<InsecriptionEntity> getAllInscriptions() {
//        return  inscriptionService.getAllInscriptions();
//    }
//
//    @GetMapping("/{id}")
//    public ResponseEntity<InsecriptionEntity> getInscriptionById(@PathVariable Integer id) {
//        Optional<InsecriptionEntity> inscription = inscriptionService.getInscriptionById(id);
//        return inscription.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
//                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
//    }
//
//    @PostMapping
//    public ResponseEntity<InsecriptionEntity> createInscription(@RequestBody InsecriptionEntity inscription) {
//        InsecriptionEntity createdInscription = inscriptionService.createInscription(inscription);
//        return new ResponseEntity<>(createdInscription, HttpStatus.CREATED);
//    }
//
//    @PutMapping("/{id}")
//    public ResponseEntity<InsecriptionEntity> updateInscription(@PathVariable Integer id, @RequestBody InsecriptionEntity updatedInscription) {
//        InsecriptionEntity updated = inscriptionService.updateInscription(id, updatedInscription);
//
//        if (updated != null) {
//            return new ResponseEntity<>(updated, HttpStatus.OK);
//        } else {
//            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
//        }
//    }
//
//    @DeleteMapping("/{id}")
//    public ResponseEntity<Void> deleteInscription(@PathVariable Integer id) {
//        inscriptionService.deleteInscription(id);
//        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
//    }
//}
