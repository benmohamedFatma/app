package com.gestionFormation.service;

import com.gestionFormation.model.SessionEntity;
import org.springframework.stereotype.Service;
import com.gestionFormation.repository.SessionRepository;

import java.util.List;
import java.util.Optional;

@Service
public class SessionService {

    private final SessionRepository sessionRepository;

    public SessionService(SessionRepository sessionRepository) {
        this.sessionRepository = sessionRepository;
    }

    public List<SessionEntity> getAllSessions() {
        return sessionRepository.findAll();
    }

    public Optional<SessionEntity> getSessionById(int id) {
        return sessionRepository.findById(id);
    }

    public SessionEntity createSession(SessionEntity session) {
        return sessionRepository.save(session);
    }

    public SessionEntity updateSession(int id, SessionEntity updatedSession) {
        Optional<SessionEntity> existingSession = sessionRepository.findById(id);

        if (existingSession.isPresent()) {
            SessionEntity sessionToUpdate = existingSession.get();
            sessionToUpdate.setIdSession(updatedSession.getIdSession());
            return sessionRepository.save(sessionToUpdate);
        } else {
            return null;
        }
    }
    public void deleteSession(int id) {
        sessionRepository.deleteById(id);
    }
}
