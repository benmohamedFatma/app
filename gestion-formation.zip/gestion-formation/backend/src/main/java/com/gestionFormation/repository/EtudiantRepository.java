package com.gestionFormation.repository;

import com.gestionFormation.model.EtudiantEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EtudiantRepository extends JpaRepository<EtudiantEntity,Integer> {

}
