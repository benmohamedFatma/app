package com.gestionFormation.controller;

import com.gestionFormation.model.FormateurEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
        import com.gestionFormation.service.FormateurService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/formateurs")
@CrossOrigin("http://localhost:3000/")
@Controller
public class FormateurController {

    private final FormateurService formateurService;

    public FormateurController(FormateurService formateurService) {
        this.formateurService = formateurService;
    }

    @GetMapping
    public List<FormateurEntity> getAllFormateurs() {
        return formateurService.getAllFormateurs();
    }

    @GetMapping("/{id}")
    public ResponseEntity<FormateurEntity> getFormateurById(@PathVariable Integer id) {
        Optional<FormateurEntity> formateur = formateurService.getFormateurById(id);
        return formateur.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PostMapping
    public ResponseEntity<FormateurEntity> createFormateur(@RequestBody FormateurEntity formateur) {
        FormateurEntity createdFormateur = formateurService.createFormateur(formateur);
        return new ResponseEntity<>(createdFormateur, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<FormateurEntity> updateFormateur(@PathVariable Integer id, @RequestBody FormateurEntity updatedFormateur) {
        FormateurEntity updated = formateurService.updateFormateur(id, updatedFormateur);

        if (updated != null) {
            return new ResponseEntity<>(updated, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteFormateur(@PathVariable Integer id) {
        formateurService.deleteFormateur(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
