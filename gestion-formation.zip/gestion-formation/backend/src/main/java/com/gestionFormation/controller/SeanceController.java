package com.gestionFormation.controller;

import com.gestionFormation.model.SeanceEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
        import com.gestionFormation.service.SeanceService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/seances")
@Controller
public class SeanceController {

    private final SeanceService seanceService;

    public SeanceController(SeanceService seanceService) {
        this.seanceService = seanceService;
    }

    @GetMapping
    public List<SeanceEntity> getAllSeances() {
        return seanceService.getAllSeances();
    }

    @GetMapping("/{id}")
    public ResponseEntity<SeanceEntity> getSeanceById(@PathVariable Integer id) {
        Optional<SeanceEntity> seance = seanceService.getSeanceById(id);
        return seance.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PostMapping
    public ResponseEntity<SeanceEntity> createSeance(@RequestBody SeanceEntity seance) {
        SeanceEntity createdSeance = seanceService.createSeance(seance);
        return new ResponseEntity<>(createdSeance, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<SeanceEntity> updateSeance(@PathVariable Integer id, @RequestBody SeanceEntity updatedSeance) {
        SeanceEntity updated = seanceService.updateSeance(id, updatedSeance);

        if (updated != null) {
            return new ResponseEntity<>(updated, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSeance(@PathVariable Integer id) {
        seanceService.deleteSeance(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
