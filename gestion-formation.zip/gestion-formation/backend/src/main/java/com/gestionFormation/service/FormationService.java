package com.gestionFormation.service;
import com.gestionFormation.model.FormationEntity;
import com.gestionFormation.repository.FormationRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
    public class FormationService {
        private final FormationRepository formationRepository;

        public FormationService(FormationRepository formationRepository) {
            this.formationRepository = formationRepository;
        }
        public List<FormationEntity> getAllFormations() {
            return formationRepository.findAll();
        }

        public Optional<FormationEntity> getFormationById(Integer id) {
            return formationRepository.findById(id);
        }

        public FormationEntity createFormation(FormationEntity formation) {
            return formationRepository.save(formation);
        }

        public FormationEntity updateFormation(Integer id, FormationEntity updatedFormation) {
            Optional<FormationEntity> existingFormation = formationRepository.findById(id);

            if (existingFormation.isPresent()) {
                FormationEntity formationToUpdate = existingFormation.get();
                formationToUpdate.setNomFormation(updatedFormation.getNomFormation());
                formationToUpdate.setDescription(updatedFormation.getDescription());
                return formationRepository.save(formationToUpdate);
            } else {
                return null;
            }
        }
        public void deleteFormation(Integer id) {
            formationRepository.deleteById(id);
        }
    }


