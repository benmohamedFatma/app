//package com.gestionFormation.model;
//
//import com.fasterxml.jackson.annotation.JsonIgnore;
//import jakarta.persistence.*;
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//import lombok.ToString;
//
//import java.time.LocalDate;
//
//@Data
//@AllArgsConstructor
//@NoArgsConstructor
//@ToString
//@Entity
//@Table(name = "Insecription")
//public class InsecriptionEntity {
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Integer id;
//    @Column(name = "Montant")
//    private double montant;
//    @Column(name = "dateInscription")
//    private LocalDate dateInscription;
////    @ManyToOne
////    @JoinColumn(name = "etudiant_id")
////    private EtudiantEntity etudiant;
//    @ManyToOne
//    @JoinColumn(name = "session_id")
//    private SessionEntity session;
//}
