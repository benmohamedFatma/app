package com.gestionFormation.service;

import com.gestionFormation.model.AdministrateurEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.gestionFormation.repository.AdministrateurRepository;

import java.util.List;

@Service
public class AdministrateurService {

    private final AdministrateurRepository administrateurRepository;
    @Autowired
    public AdministrateurService(AdministrateurRepository administrateurRepository){
        this.administrateurRepository= administrateurRepository;
    }

    public List<AdministrateurEntity> getAllAdmins() {
        return administrateurRepository.findAll();
    }

    public AdministrateurEntity getAdminById(Integer id) {
        return administrateurRepository.findById(id).orElse(null);
    }

    public AdministrateurEntity createAdmin(AdministrateurEntity admin) {
        return administrateurRepository.save(admin);
    }

    public AdministrateurEntity updateAdmin(Integer id, AdministrateurEntity updatedAdmin) {
        return administrateurRepository.findById(id)
                .map(existingAdmin -> {
                    // Mettez à jour les champs nécessaires de l'administrateur existant avec les valeurs de updatedAdmin
                    existingAdmin.setEmail(updatedAdmin.getEmail());
                    existingAdmin.setNumTEL(updatedAdmin.getNumTEL());
                    existingAdmin.setNom(updatedAdmin.getNom());
                    existingAdmin.setPrenom(updatedAdmin.getPrenom());
                    // ... autres champs ...
                    return administrateurRepository.save(existingAdmin);
                })
                .orElse(null);
    }

    public void deleteAdmin(Integer id) {
        administrateurRepository.deleteById(id);
    }
}

