package com.gestionFormation.controller;

import com.gestionFormation.model.MatièreEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
        import com.gestionFormation.service.MatiereService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/matieres")
@Controller
public class MatiereController {

    private final MatiereService matiereService;

    public MatiereController(MatiereService matiereService) {
        this.matiereService = matiereService;
    }

    @GetMapping
    public List<MatièreEntity> getAllMatieres() {
        return matiereService.getAllMatieres();
    }

    @GetMapping("/{id}")
    public ResponseEntity<MatièreEntity> getMatiereById(@PathVariable Integer id) {
        Optional<MatièreEntity> matiere = matiereService.getMatiereById(id);
        return matiere.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PostMapping
    public void createMatiere(@RequestBody MatièreEntity matiere) {
        matiereService.createMatiere(matiere);
       //return new ResponseEntity<>(createdMatiere, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<MatièreEntity> updateMatiere(@PathVariable Integer id, @RequestBody MatièreEntity updatedMatiere) {
        MatièreEntity updated = matiereService.updateMatiere(id, updatedMatiere);

        if (updated != null) {
            return new ResponseEntity<>(updated, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMatiere(@PathVariable Integer id) {
        matiereService.deleteMatiere(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
