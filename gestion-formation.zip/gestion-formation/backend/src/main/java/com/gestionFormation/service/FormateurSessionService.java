package com.gestionFormation.service;

import com.gestionFormation.model.FormateurSessionEntity;
import com.gestionFormation.repository.FormateurSessionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FormateurSessionService {

    private final FormateurSessionRepository formateurSessionRepository;

    @Autowired
    public FormateurSessionService(FormateurSessionRepository formateurSessionRepository) {
        this.formateurSessionRepository = formateurSessionRepository;
    }

    public List<FormateurSessionEntity> getAllFormateurSessions() {
        return formateurSessionRepository.findAll();
    }

    public Optional<FormateurSessionEntity> getFormateurSessionById(Integer id) {
        return formateurSessionRepository.findById(id);
    }

    public FormateurSessionEntity createFormateurSession(FormateurSessionEntity formateurSession) {
        return formateurSessionRepository.save(formateurSession);
    }

    public void deleteFormateurSessionById(Integer id) {
        formateurSessionRepository.deleteById(id);
    }
}
