package com.gestionFormation.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table(name = "Administrateur")
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class AdministrateurEntity extends PersonneEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idAdmin;
    @Column(name ="password")
    private String password;
}
