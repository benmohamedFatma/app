//package com.gestionFormation.repository;
//
//import com.gestionFormation.model.InsecriptionEntity;
//import org.springframework.data.jpa.repository.JpaRepository;
//
//public interface InscriptionRepository extends JpaRepository<InsecriptionEntity,Integer> {
//}
