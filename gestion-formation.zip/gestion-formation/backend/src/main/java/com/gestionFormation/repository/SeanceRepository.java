package com.gestionFormation.repository;

import com.gestionFormation.model.SeanceEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SeanceRepository extends JpaRepository<SeanceEntity,Integer> {
}
