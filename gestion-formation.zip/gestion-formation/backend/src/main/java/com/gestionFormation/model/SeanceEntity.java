package com.gestionFormation.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "Seance")
public class SeanceEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_seance")
    private Integer idSeance;

    @Column(name = "date")
    private LocalDate date;


    @ManyToOne
    @JoinColumn(name = "session_id")
//    @JsonIgnore
    private SessionEntity session;
//    @ManyToMany(mappedBy = "seances")
//    @JsonIgnore
//    private Set<PrésenceEntity> présences = new HashSet<>();
}
