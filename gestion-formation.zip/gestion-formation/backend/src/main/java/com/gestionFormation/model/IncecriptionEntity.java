package com.gestionFormation.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Entity
@Table(name = "Incecription")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class IncecriptionEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(name = "dateInsecription")
    private LocalDate dateInsecription;
    @ManyToOne
    private SessionEntity session;

    @ManyToOne
    private EtudiantEntity etudiant;
}
