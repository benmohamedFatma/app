package com.gestionFormation.repository;

import com.gestionFormation.model.MatièreEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MatiereRepository extends JpaRepository<MatièreEntity,Integer> {
}
