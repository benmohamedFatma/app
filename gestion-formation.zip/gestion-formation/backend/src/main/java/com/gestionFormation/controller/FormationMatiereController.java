package com.gestionFormation.controller;

import com.gestionFormation.model.FormationMatiereEntity;
import com.gestionFormation.service.FormationMatiereService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/formationmatieres")
public class FormationMatiereController {

    private final FormationMatiereService formationMatiereService;

    @Autowired
    public FormationMatiereController(FormationMatiereService formationMatiereService) {
        this.formationMatiereService = formationMatiereService;
    }

    @GetMapping
    public List<FormationMatiereEntity> getAllFormationMatieres() {
        return formationMatiereService.getAllFormationMatieres();
    }

    @GetMapping("/{id}")
    public FormationMatiereEntity getFormationMatiereById(@PathVariable Integer id) {
        return formationMatiereService.getFormationMatiereById(id).orElse(null);
    }

    @PostMapping
    public FormationMatiereEntity createFormationMatiere(@RequestBody FormationMatiereEntity formationMatiere) {
        return formationMatiereService.createFormationMatiere(formationMatiere);
    }

    @DeleteMapping("/{id}")
    public void deleteFormationMatiereById(@PathVariable Integer id) {
        formationMatiereService.deleteFormationMatiereById(id);
    }
}
