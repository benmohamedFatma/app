package com.gestionFormation.service;
import com.gestionFormation.model.PrésenceEntity;
import org.springframework.stereotype.Service;
import com.gestionFormation.repository.PresenceRepository;

import java.util.List;
import java.util.Optional;

@Service
public class PresenceService {
    private final PresenceRepository presenceRepository;

    public PresenceService(PresenceRepository presenceRepository) {
        this.presenceRepository = presenceRepository;
    }

    public List<PrésenceEntity> getAllPresences() {
        return presenceRepository.findAll();
    }

    public Optional<PrésenceEntity> getPresenceById(Integer id) {
        return presenceRepository.findById(id);
    }

    public PrésenceEntity createPresence(PrésenceEntity presence) {
        return presenceRepository.save(presence);
    }

    public PrésenceEntity updatePresence(Integer id, PrésenceEntity updatedPresence) {
        Optional<PrésenceEntity> existingPresence = presenceRepository.findById(id);

        if (existingPresence.isPresent()) {
            PrésenceEntity presenceToUpdate = existingPresence.get();
            presenceToUpdate.setEstPresent(updatedPresence.isEstPresent());
            return presenceRepository.save(presenceToUpdate);
        } else {
            return null;
        }
    }

    public void deletePresence(Integer id) {
        presenceRepository.deleteById(id);
    }
}
