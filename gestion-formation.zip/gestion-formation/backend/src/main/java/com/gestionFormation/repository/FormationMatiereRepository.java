package com.gestionFormation.repository;

import com.gestionFormation.model.FormationEntity;
import com.gestionFormation.model.MatièreEntity;
import com.gestionFormation.model.FormationMatiereEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FormationMatiereRepository extends JpaRepository<FormationMatiereEntity, Integer> {
}
