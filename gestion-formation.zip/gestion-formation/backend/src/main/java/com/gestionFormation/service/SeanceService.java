package com.gestionFormation.service;
import com.gestionFormation.model.SeanceEntity;
import org.springframework.stereotype.Service;
import com.gestionFormation.repository.SeanceRepository;

import java.util.List;
import java.util.Optional;

@Service
public class SeanceService {
    private final SeanceRepository seanceRepository;

    public SeanceService(SeanceRepository seanceRepository) {
        this.seanceRepository = seanceRepository;
    }

    public List<SeanceEntity> getAllSeances() {
        return seanceRepository.findAll();
    }

    public Optional<SeanceEntity> getSeanceById(Integer id) {
        return seanceRepository.findById(id);
    }

    public SeanceEntity createSeance(SeanceEntity seance) {
        return seanceRepository.save(seance);
    }

    public SeanceEntity updateSeance(Integer id, SeanceEntity updatedSeance) {
        Optional<SeanceEntity> existingSeance = seanceRepository.findById(id);

        if (existingSeance.isPresent()) {
            SeanceEntity seanceToUpdate = existingSeance.get();
            seanceToUpdate.setDate(updatedSeance.getDate());
            return seanceRepository.save(seanceToUpdate);
        } else {
            return null;
        }
    }

    public void deleteSeance(Integer id) {
        seanceRepository.deleteById(id);
    }
}

