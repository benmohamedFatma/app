package com.gestionFormation.controller;

import com.gestionFormation.model.PrésenceEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
        import com.gestionFormation.service.PresenceService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/presences")
@Controller
public class PresenceController {

    private final PresenceService presenceService;

    public PresenceController(PresenceService presenceService) {
        this.presenceService = presenceService;
    }

    @GetMapping
    public List<PrésenceEntity> getAllPresences() {
        return presenceService.getAllPresences();
    }

    @GetMapping("/{id}")
    public ResponseEntity<PrésenceEntity> getPresenceById(@PathVariable Integer id) {
        Optional<PrésenceEntity> presence = presenceService.getPresenceById(id);
        return presence.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PostMapping
    public ResponseEntity<PrésenceEntity> createPresence(@RequestBody PrésenceEntity presence) {
        PrésenceEntity createdPresence = presenceService.createPresence(presence);
        return new ResponseEntity<>(createdPresence, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<PrésenceEntity> updatePresence(@PathVariable Integer id, @RequestBody PrésenceEntity updatedPresence) {
        PrésenceEntity updated = presenceService.updatePresence(id, updatedPresence);

        if (updated != null) {
            return new ResponseEntity<>(updated, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePresence(@PathVariable Integer id) {
        presenceService.deletePresence(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
