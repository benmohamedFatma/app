package com.gestionFormation.repository;

import com.gestionFormation.model.IncecriptionEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EtudiantSessionRepository extends JpaRepository<IncecriptionEntity, Integer> {
}
