package com.gestionFormation.repository;

import com.gestionFormation.model.FormateurEntity;
import com.gestionFormation.model.FormateurSessionEntity;
import com.gestionFormation.model.SessionEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface FormateurSessionRepository extends JpaRepository<FormateurSessionEntity, Integer> {

}
