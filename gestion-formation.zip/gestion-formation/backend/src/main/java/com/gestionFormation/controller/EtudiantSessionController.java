package com.gestionFormation.controller;

import com.gestionFormation.model.IncecriptionEntity;
import com.gestionFormation.service.EtudiantSessionService;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/etudiant-sessions")
public class EtudiantSessionController {

    private final EtudiantSessionService etudiantSessionService;

    public EtudiantSessionController(EtudiantSessionService etudiantSessionService) {
        this.etudiantSessionService = etudiantSessionService;
    }

    @GetMapping
    public List<IncecriptionEntity> getAllEtudiantSessions() {
        return etudiantSessionService.getAllEtudiantSessions();
    }

    @GetMapping("/{id}")
    public IncecriptionEntity getEtudiantSessionById(@PathVariable Integer id) {
        return etudiantSessionService.getEtudiantSessionById(id).orElse(null);
    }

    @PostMapping
    public IncecriptionEntity createEtudiantSession(@RequestBody IncecriptionEntity etudiantSession) {
        return etudiantSessionService.createEtudiantSession(etudiantSession);
    }

    @DeleteMapping("/{id}")
    public void deleteEtudiantSessionById(@PathVariable Integer id) {
        etudiantSessionService.deleteEtudiantSessionById(id);
    }
}

