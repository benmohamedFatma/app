package com.gestionFormation.repository;

import com.gestionFormation.model.SessionEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SessionRepository extends JpaRepository<SessionEntity, Integer>{
}
