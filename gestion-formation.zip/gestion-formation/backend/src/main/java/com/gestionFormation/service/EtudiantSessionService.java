package com.gestionFormation.service;

import com.gestionFormation.model.IncecriptionEntity;
import com.gestionFormation.repository.EtudiantSessionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EtudiantSessionService {

    private final EtudiantSessionRepository etudiantSessionRepository;

    @Autowired
    public EtudiantSessionService(EtudiantSessionRepository etudiantSessionRepository) {
        this.etudiantSessionRepository = etudiantSessionRepository;
    }

    public List<IncecriptionEntity> getAllEtudiantSessions() {
        return etudiantSessionRepository.findAll();
    }

    public Optional<IncecriptionEntity> getEtudiantSessionById(Integer id) {
        return etudiantSessionRepository.findById(id);
    }

    public IncecriptionEntity createEtudiantSession(IncecriptionEntity etudiantSession) {
        return etudiantSessionRepository.save(etudiantSession);
    }

    public void deleteEtudiantSessionById(Integer id) {
        etudiantSessionRepository.deleteById(id);
    }
}
