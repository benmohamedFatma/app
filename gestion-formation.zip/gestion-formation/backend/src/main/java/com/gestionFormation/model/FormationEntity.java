package com.gestionFormation.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "Formation")
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class FormationEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "nomFormation")
    private String nomFormation;

    @Column(name = "Description")
    private String description;
    @OneToMany(mappedBy = "formation")
    @JsonIgnore
    private List<SessionEntity> sessions = new ArrayList<>();

}